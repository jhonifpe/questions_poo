package resolucao.lista;

import java.util.Scanner;

public class question_two {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		float peso; 
		System.out.println("Digite seu Peso");
		peso = input.nextFloat();
		
		float altura;
		System.out.println("Digite sua Altura");
		altura = input.nextFloat();
		
		float calc_imc = peso/(altura*altura);
		
		//System.out.println("seu IMC é -> " + Math.round(calc_imc * 100.0)/100.0);
		System.out.printf("Seu IMC é -> %.2f" , calc_imc);
		
	}
		
}
