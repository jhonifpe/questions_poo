package resolucao.lista;

import java.util.Scanner;

public class question_three {

	public static void main(String[] args) {
		
		Scanner store = new Scanner(System.in);
		
		float baseMaior;
		System.out.println("digite o valor da base maior do trapezio retangulo:");
		baseMaior = store.nextFloat();
		
		float baseMenor;
		System.out.println("digite o valor da base menor do trapezio retangulo:");
		baseMenor = store.nextFloat();
		
		float altura;
		System.out.println("digite a altura do trapezio retangulo:");
		altura = store.nextFloat();
		
		float area = ((baseMaior + baseMenor) * altura) / 2;
		
		System.out.printf("A área do trapezio é %.2f cm²", area);
		
	}

}
