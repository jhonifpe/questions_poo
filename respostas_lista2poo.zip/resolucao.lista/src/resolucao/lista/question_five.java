package resolucao.lista;

import java.util.Scanner;

public class question_five {

	public static void main(String[] args) {
		
Scanner armazenamento = new Scanner(System.in);
		
		int number;
		System.out.println("digite um numero:");
		number = armazenamento.nextInt();
				
		question_five.impar_par(number);
		
	}
	
	public static void impar_par(int num) {
		
		if (num % 2 == 0) {
			System.out.println("o numero "+ num + " é par");
		} else {
			System.out.println("o numero "+ num + " é ímpar");
		}
	
	}


}
