package resolucao.lista;

import java.util.Scanner;

public class question_four {

	public static void main(String[] args) {
		Scanner armazenar = new Scanner(System.in);
		
		int num_one;
		System.out.println("digite o primeiro numero:");
		num_one = armazenar.nextInt();
		
		int num_two;
		System.out.println("digite o segundo numero:");
		num_two = armazenar.nextInt();
		
		System.out.println("o maior numero é "+ question_four.maiorNumber(num_one, num_two));
		
	}
	
	public static int maiorNumber(int n1, int n2) {
		
		if (n1 > n2) {
			return n1;
		} else {
			return n2;
		}
	
	}

}
