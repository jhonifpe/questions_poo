package resolucao.lista;

import java.util.Scanner;

public class question_one {

	public static void main (String[] args) {
		
		int num_inteiro = 0;
		long num_long = 0; 
		float num_float = 0f;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("digite um numero do tipo inteiro :");
		num_inteiro = input.nextInt();
		
		System.out.println("digite um numero do tipo long :");
		num_long = input.nextLong();
		
		System.out.println("digite um numero do tipo float :");
		num_float = input.nextFloat();
		
		System.out.printf("o numero inteiro digitado foi %d ", num_inteiro);
		System.out.printf("o numero long digitado foi %d ", num_long);
		System.out.printf("o numero float digitado foi %f ", num_float);
	}
}
