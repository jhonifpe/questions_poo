package listadois_poo;

import java.util.Scanner;

public class segunda_lista {

	public static void main(String[] args) {
		
// 1° -> media de 5 notas.

Scanner entrada = new Scanner(System.in);
		
		double n1,n2,n3,n4,n5;
		double med;
		
		System.out.println("digite sua primeira nota");
		n1 = entrada.nextDouble();
		
		System.out.println("digite sua segunda nota");
		n2 = entrada.nextDouble();
		
		System.out.println("digite sua terceira nota");
		n3 = entrada.nextDouble();	
		
		System.out.println("digite sua quarta nota");
		n4 = entrada.nextDouble();
		
		System.out.println("digite sua quinta nota");
		n5 = entrada.nextDouble();
		
		double[] array_notas = {n1,n2,n3,n4,n5};
		med = (n1+n2+n3+n4+n5)/array_notas.length;
		
		System.out.println("sua media é"+med);
	
// 2° -> impressão de forma inversa dos 10 inteiros.
		
		int [] vetor = {1,2,3,4,5,6,7,8,9,10};
		
		for(int i =vetor.length-1;i>=0; i--) {
			System.out.println(vetor[i]);
		}
		
// 3° -> array com 100 numeros inteiros aleatorios, imprimir de forma normal e inversa.
		
		int[] array = new int[100];

		for(int i=1; i<=array.length; i++) {
			if(i != 100) {
				System.out.print(i + ",");
			} else {
				System.out.print(i + "\n");
			}
			
		}
		for(int j= array.length; j > 0; j--) {
			System.out.print(j + ",");
		}

		
//5° -> array com 100 numeros inteiros aleatorios, imprimir os numeros impares.
		
		int[] array_impar = new int[100];

		for(int i=1; i<=array_impar.length; i++) {
				if(i % 2 != 0) {
					System.out.print(i + " ");
				}
				
			}

		
//6° -> array com 100 numeros inteiros aleatorios, imprimir os numeros pares.
			
		int[] array_par = new int[100];

		for(int x=1; x<=array_par.length; x++) {
				if(x % 2 == 0) {
					System.out.print(x + " ");
				}
				
			}
	}
	
}
